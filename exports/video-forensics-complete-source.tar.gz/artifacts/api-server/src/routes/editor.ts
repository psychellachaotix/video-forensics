import { execFile } from "node:child_process";
import { randomUUID } from "node:crypto";
import { createWriteStream, promises as fs } from "node:fs";
import path from "node:path";
import { pipeline } from "node:stream/promises";
import { promisify } from "node:util";
import { ExportEditedVideoBody } from "@workspace/api-zod";
import { db, videosTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { ObjectStorageService } from "../lib/objectStorage";

const execFileAsync = promisify(execFile);
const router: IRouter = Router();
const storage = new ObjectStorageService();

const videoFilters: Record<string, string> = {
  none: "null",
  grayscale: "hue=s=0",
  warm: "colorbalance=rs=.12:bs=-.08",
  cool: "colorbalance=rs=-.08:bs=.12",
  contrast: "eq=contrast=1.3:saturation=1.1",
};

function escapeDrawText(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/:/g, "\\:").replace(/%/g, "\\%");
}

router.post("/editor/export", async (req, res): Promise<void> => {
  const parsed = ExportEditedVideoBody.safeParse(req.body);
  if (!parsed.success || parsed.data.clips.some((clip) => clip.end <= clip.start)) {
    res.status(400).json({ error: "Neplatný projekt editoru." });
    return;
  }

  const project = parsed.data;
  const [source] = await db.select().from(videosTable).where(eq(videosTable.id, project.analysisId)).limit(1);
  if (!source?.originalPath || source.mediaType !== "video") {
    res.status(404).json({ error: "Zdrojové video nebylo nalezeno." });
    return;
  }

  const requestId = randomUUID();
  const inputPath = path.join("/tmp", `editor-input-${requestId}${path.extname(source.filename) || ".mp4"}`);
  const outputPath = path.join("/tmp", `editor-output-${requestId}.mp4`);
  const filterPath = path.join("/tmp", `editor-filter-${requestId}.txt`);

  try {
    const objectFile = await storage.getObjectEntityFile(source.originalPath);
    await pipeline(objectFile.createReadStream(), createWriteStream(inputPath));
    const probe = await execFileAsync("ffprobe", [
      "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", inputPath,
    ]);
    const hasAudio = probe.stdout.trim().length > 0;

    const graph: string[] = [];
    project.clips.forEach((clip, index) => {
      const duration = clip.end - clip.start;
      const fade = clip.transition === "fade" && duration > 0.5
        ? `,fade=t=in:st=0:d=0.25,fade=t=out:st=${Math.max(0, duration - 0.25)}:d=0.25`
        : "";
      graph.push(`[0:v]trim=start=${clip.start}:end=${clip.end},setpts=PTS-STARTPTS,${videoFilters[project.filter]}${fade}[v${index}]`);
      if (hasAudio && !project.muted) {
        graph.push(`[0:a]atrim=start=${clip.start}:end=${clip.end},asetpts=PTS-STARTPTS,volume=${project.volume}[a${index}]`);
      }
    });

    const videoInputs = project.clips.map((_, index) => `[v${index}]`).join("");
    if (hasAudio && !project.muted) {
      const inputs = project.clips.map((_, index) => `[v${index}][a${index}]`).join("");
      graph.push(`${inputs}concat=n=${project.clips.length}:v=1:a=1[vbase][aout]`);
    } else {
      graph.push(`${videoInputs}concat=n=${project.clips.length}:v=1:a=0[vbase]`);
    }

    let current = "vbase";
    project.texts.forEach((text, index) => {
      const output = `vtext${index}`;
      graph.push(
        `[${current}]drawtext=text='${escapeDrawText(text.text)}':fontcolor=${text.color}:fontsize=${text.size}:x=(w-text_w)*${text.x / 100}:y=(h-text_h)*${text.y / 100}:` +
        `box=1:boxcolor=black@0.45:boxborderw=12:enable='between(t,${text.start},${text.end})'[${output}]`,
      );
      current = output;
    });
    graph.push(`[${current}]format=yuv420p[vout]`);
    await fs.writeFile(filterPath, graph.join(";\n"), "utf8");

    const args = [
      "-y", "-i", inputPath, "-filter_complex_script", filterPath,
      "-map", "[vout]", ...(hasAudio && !project.muted ? ["-map", "[aout]"] : ["-an"]),
      "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
      ...(hasAudio && !project.muted ? ["-c:a", "aac", "-b:a", "192k"] : []),
      "-movflags", "+faststart", outputPath,
    ];
    await execFileAsync("ffmpeg", args, { maxBuffer: 16 * 1024 * 1024 });
    res.type("video/mp4");
    res.setHeader("Content-Disposition", `attachment; filename="video-forensics-edit-${source.id}.mp4"`);
    res.sendFile(outputPath, () => {
      void Promise.all([inputPath, outputPath, filterPath].map((file) => fs.rm(file, { force: true })));
    });
  } catch (error) {
    req.log.error({ err: error, analysisId: project.analysisId }, "Video editor export failed");
    await Promise.all([inputPath, outputPath, filterPath].map((file) => fs.rm(file, { force: true })));
    if (!res.headersSent) res.status(500).json({ error: "Export videa se nepodařilo dokončit." });
  }
});

export default router;